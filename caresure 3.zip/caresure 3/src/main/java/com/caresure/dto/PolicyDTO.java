package com.caresure.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class PolicyDTO {
    private String title;
    private String description;
    private String status;
}
